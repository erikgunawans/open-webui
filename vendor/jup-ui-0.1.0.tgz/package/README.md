# @jup/ui

Brand primitives for JUP product surfaces — React 18, TypeScript, plain CSS
custom properties. Built so `/design-sync` can feed Claude Design real on-brand
components instead of generic Tailwind.

## Install

```bash
bun install
bun run check   # typecheck → build → validate conventions
bun run storybook
```

## Use

```tsx
import { JupUIProvider, ToastProvider, Button } from "@jup/ui";
import "@jup/ui/styles.css";

export function App() {
  return (
    <JupUIProvider theme="auto">
      <ToastProvider>
        <Button>Setujui gate 3</Button>
      </ToastProvider>
    </JupUIProvider>
  );
}
```

`JupUIProvider` renders the `.jup-root` element every token is scoped to.
**Without it components inherit nothing and render unstyled.**

### Fonts

Space Grotesk and Space Mono are the identity typefaces (GSM 2023 p.28). They
are *not* bundled — load them in the host, e.g. from Google Fonts, or copy the
`woff2` files out of the `jup-design` skill's `assets/fonts/`. The stacks
degrade to system UI, so a missing webfont costs brand, not layout.

### Avoiding a light flash on reload

```tsx
import { jupThemeScript } from "@jup/ui";
<script dangerouslySetInnerHTML={{ __html: jupThemeScript() }} />
```

## What's here

20 primitives + the provider.

| Group | Components |
|---|---|
| Actions | `Button`, `IconButton` |
| Forms | `Field`, `Input`, `Textarea`, `Select`, `Checkbox`, `Switch` |
| Display | `Badge`, `Tag`, `Card`, `Avatar`, `Skeleton`, `Spinner` |
| Feedback | `Alert`, `Dialog`, `Tooltip`, `ToastProvider` / `useToast` |
| Navigation | `Tabs`, `DropdownMenu` |

Chat composites — `ChatMessage`, `MessageInput`, `Sidebar`, `ModelSelector` —
are **not** in v1. They carry more brand signal than the primitives do and are
the obvious v2.

## Brand source of truth

**`~/jup/brand/tokens/colors.css`** — ratified by Erik 2026-09-18. It is the
layer that also feeds `@jup/design-system`, so the two packages share one
palette. Brand `#079F4E`, blue `#1E6FB0`, ink `#12201A`, paper `#F4F7F2`,
IBM Plex Sans / Fraunces / IBM Plex Mono, rounded on an 8px rhythm with real
elevation.

`src/tokens/identity.css` is a **vendored copy**, not an import — because
`@jup/design-system` is unpublished and `/design-sync` needs a self-contained
`dist/`. `bun run validate:tokens` diffs all 42 light and 36 dark canonical
tokens against it and fails the build on drift. Vendoring without that check is
how two "canonical" layers came to exist in the first place.

> This package previously carried the **Graphic Standard Manual 2023** palette
> (Pigment Green `#00A550`, Space Grotesk, square corners, near-banned shadows).
> That was reversed on ratification. The swap touched more than colour and type:
> the GSM system is square and flat, JUP 2.0 is rounded and elevated, so
> `radius.css`, `elevation.css` and the house-style section of
> `.design-sync/conventions.md` changed too. My earlier claim that reversing was
> "a one-file edit" was true only of hex values and font names.

The GSM defines no dark theme, only an inverse scope for dark print sections.
A chat product needs a real one, so `src/tokens/semantic.css` extends it: Rich
Black is the floor and the brand lifts to `green-300`/`blue-200` for headroom
at small sizes.

## Contrast

The canonical palette defines colours, not which of them is legible in which
role. Three splits exist because measurement said so, and all of them were
verified in real Chrome, not assumed:

- **Fill vs text, per hue.** `--jup-brand` `#079F4E` as *text* on paper is
  **3.20:1** and fails AA — `--jup-text-brand` resolves to `--jup-brand-deep`
  (5.92:1). Likewise every status hue has a `-text` variant, because used as
  words on their own `-bg` they measure 3.05 / 4.60 / 2.65 / 4.02:1.
- **Label on a filled surface, per hue.** In light, brand and amber need the
  ink label (white fails at 3.45 and 3.03); blue and red need white. In dark
  every accent is a pastel, so all four take the dark label. Hence
  `--jup-text-on-{brand,alt,danger,warning}` rather than one token.
- **`--jup-text-muted` is 4.15:1** — large text only. Components use
  `--jup-text-secondary` (7.48:1) for helper text and keep `muted` for
  placeholders and decorative icons.

Swept across 9 stories × 2 themes: zero failures. Disabled controls are exempt
under WCAG 1.4.3 and are reported as such rather than silently passed.

## Architecture

- **Plain CSS custom properties, no Tailwind.** Both existing JUP systems are
  plain-CSS; a third convention would not help. It also makes `/design-sync`'s
  "everything reachable from the `styles.css` `@import` closure" rule trivial
  to satisfy.
- `src/tokens/identity.css` is the only file holding raw hex values.
- `src/styles.css` is the whole stylesheet and the `@import` closure. A
  component whose CSS is not imported there will render unstyled in Claude
  Design — `bun run validate` does not catch that, so add the import when you
  add a component.
- `react`/`react-dom` stay external in `dist/`. If `react-dom` is ever bundled,
  `/design-sync` throws `SCHEDULER_MISSING`.

## Gates

`bun run check` runs three:

1. `typecheck` — `tsc --noEmit`, strict, `noUncheckedIndexedAccess` on.
2. `build` — tsup → `dist/{index.js,index.d.ts,index.css}`.
3. `validate` — every token and component named in
   `.design-sync/conventions.md` must exist in `dist/`. That file is inlined
   into the design agent's system prompt, so a name there that does not exist
   teaches it to write CSS that silently does nothing.

## Accessibility

Deliberate, because the source system had gaps here:

- `IconButton` **requires** `label`; the type refuses an unnamed icon button.
- `Field` generates the control id and the `aria-describedby` chain by context.
  Error replaces hint rather than appending, so stale help text is not read
  over an error.
- `Dialog` traps Tab focus, restores focus on close, locks body scroll, and is
  `role="dialog" aria-modal="true"`.
- `Tabs` follows the WAI-ARIA tabs pattern — arrows wrap, Home/End jump, and
  only the active tab is in the page tab order.
- `DropdownMenu` follows the menu-button pattern; the trigger is focusable
  (the original's was not), Escape returns focus to it.
- `.jup-hover-reveal` uses opacity, not `display`, so keyboard focus can still
  reach a revealed control.
- One focus treatment for the whole system, on `:focus-visible`.
- Every animation has a `prefers-reduced-motion` answer.
